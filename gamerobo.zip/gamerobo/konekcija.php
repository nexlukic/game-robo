<?php
$conn = mysqli_connect('localhost', 'roughlyc_nex', 'sifra1','roughlyc_gamerobo');
?>