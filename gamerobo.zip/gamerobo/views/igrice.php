

<?php
if(isset($_REQUEST['limit'])){
$limit=$_GET['limit'];
if($limit=='1'){

    $page=0;
}
else{
    $page=($limit*3)-3;
}
$upit="SELECT * from igrice limit $page,3";
$result=mysqli_query($conn,$upit);
$a=mysqli_num_rows($result);
}
else{
    $upit="SELECT * from igrice limit 0,3";
    $result=mysqli_query($conn,$upit);

}
mysqli_fetch_array($result);
?>
<div class="wthreetabsaits" id="wthreetabsaits">
    <h3>Collection</h3>
    <div class="tabs tabs-style-line">
      <nav class="container">
        <ul>
          <li></li>

        </ul>
      </nav>
      <div class="content-wrap">
        <section>
          <div>
            <?php foreach($result as $r):?>
            <div class="col-lg-4">
            <div class="item">
              <div class="agileinfoitem-image">
                <img src="<?php echo $r['putanja']?>" alt="Game Robo">
              </div>
              <h3><?php echo $r['naziv']?></h3>
              <h4 id="preuzimanje<?php echo $r['id']?>"><?php echo $r['broj']?> Downloads</h4>
              <div class="wthreeratingaits">
               <input type="hidden" id="skini" >
              </div>
              <div class="wthreeitemdownload">

                <button onClick="download(<?= $r['id'];?>)" id="skini<?= $r['id'];?>">Download</button>
              </div>
            </div>
            </div>
          <?php endforeach; ?>
          </selection>
          </div>

      </div>
    </div>
</div>
<div  class="text-center" style="background-color:black;">
    <nav aria-label="...">
        <ul class="pagination pagination-lg">
            <?php
            $upit="SELECT * from igrice";
            $rezultat=mysqli_query($conn,$upit);
            $a=mysqli_num_rows($rezultat);
            $broj=ceil($a/3);
            ?>
            <?php for($i=1;$i<=$broj;$i++):?>
                <li class="page-item"><a class="page-link"  href="index.php?page=igrice&limit=<?php echo $i?>"><p style="color:black;"><?php echo $i?></p></a></li>
            <?php endfor;?>
        </ul>
    </nav>
</div>

