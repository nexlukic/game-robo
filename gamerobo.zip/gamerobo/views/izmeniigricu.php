<link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<!-- MetisMenu CSS -->
<link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

<!-- Custom CSS -->
<link href="../data/dist/css/sb-admin-2.css" rel="stylesheet">

<!-- Morris Charts CSS -->
<link href="../vendor/morrisjs/morris.css" rel="stylesheet">

<!-- Custom Fonts -->
<link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<?php
include('../konekcija.php');
$id=$_REQUEST['id'];
$upit="SELECT * from igrice where id=$id";
$result=mysqli_query($conn,$upit);
if(isset($_REQUEST['izmeni'])) {
    $target = "../images/";
    $target = $target . basename($_FILES['file']['name']);
    if ($target == '../images/') {
        $id = $_REQUEST['id'];
        $naziv = $_REQUEST['naziv'];
        $broj = $_REQUEST['broj'];
        $zanr = $_REQUEST['zanr'];
        $anketa = $_REQUEST['anketa'];
        $upit = "UPDATE igrice SET naziv='$naziv',broj='$broj',id_zandra='$zanr',anketa='$anketa' WHERE id=$id";
        $rezultat = mysqli_query($conn, $upit);
        if ($rezultat) {
            header('Location: admin.php?page=igrice');
        }
    } else {
        $target = "../images/";
        $target = $target . basename($_FILES['file']['name']);
        if(move_uploaded_file($_FILES['file']['tmp_name'], $target)){
            $target = "images/";
            $target = $target . basename($_FILES['file']['name']);
            $id = $_REQUEST['id'];
            $naziv = $_REQUEST['naziv'];
            $broj = $_REQUEST['broj'];
            $zanr = $_REQUEST['zanr'];
            $anketa = $_REQUEST['anketa'];
            $upit = "UPDATE igrice SET naziv='$naziv',putanja='$target',broj='$broj',id_zandra='$zanr',anketa='$anketa' WHERE id=$id";
            $rezultat = mysqli_query($conn, $upit);
            if ($rezultat) {
                header('Location: admin.php?page=igrice');
            }
        }
    }
}
?>
<?php foreach($result as $r):?>
<div class="col-lg-12  col-lg-offset-5 centred">
  <form class="form-horizontal" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data">
    <fieldset>
      <div id="legend">
        <legend class="">Izmeni</legend>
      </div>

        <input type="hidden" name="id" value="<?php echo $r['id']?>">
      <div class="control-group">
        <!-- Username -->
        <label class="control-label"  for="naziv">Naziv</label>
        <div class="controls">
          <input type="text" value="<?php echo $r['naziv'];?>" name="naziv" placeholder="" class="input-xlarge">

        </div>
      </div>

      <div class="control-group">
        <!-- E-mail -->
        <label class="control-label" >slika</label>
        <div class="controls">
            <tr><td><img src="../<?php echo $r['putanja'];?>" height="200" width="200"></td></tr>
        </div>
          <div class="control-group">
              <!-- E-mail -->
              <label class="control-label" >dodaj drugu sliku</label>
              <div class="controls">
                  <input type="file" name="file">
              </div>
      </div>

      <div class="control-group">
        <!-- Password-->
        <label class="control-label" >Broj preuzimanja</label>
        <div class="controls">
          <input type="text" value="<?php echo $r['broj'];?>" name="broj" placeholder="" class="input-xlarge">
        </div>
      </div>

      <div class="control-group">
        <!-- Password -->
        <label class="control-label"  for="telephone">Zanr</label>
        <div class="controls">
          <input type="text" value="<?php echo $r['id_zandra'];?>" name="zanr" placeholder="" class="input-xlarge">
        </div>
      </div>
    <div class="control-group">
        <!-- Password -->
        <label class="control-label"  for="telephone">Anketa</label>
        <div class="controls">
            <input type="text" value="<?php echo $r['anketa'];?>" name="anketa" placeholder="" class="input-xlarge">
        </div>
    </div>

      <div class="control-group">
        <!-- Button -->
        <div class="controls">
        </br>
          <button type="submit" class="btn btn-success" name="izmeni">Izmeni</button>
        </div>
      </div>
    </fieldset>
  </form>
</div>
<?php endforeach;?>