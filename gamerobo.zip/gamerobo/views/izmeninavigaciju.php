<link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<!-- MetisMenu CSS -->
<link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

<!-- Custom CSS -->
<link href="../data/dist/css/sb-admin-2.css" rel="stylesheet">

<!-- Morris Charts CSS -->
<link href="../vendor/morrisjs/morris.css" rel="stylesheet">

<!-- Custom Fonts -->
<link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<?php
$conn = mysqli_connect('localhost', 'root', '','gamerobo');
$id=$_REQUEST['id'];
$upit="SELECT * from navigacija where id=$id";
$result=mysqli_query($conn,$upit);
if(isset($_REQUEST['izmeni'])){
    $id=$_REQUEST['id'];
    $naziv=$_REQUEST['naziv'];
    $link=$_REQUEST['link'];
    $upit="UPDATE navigacija SET naziv='$naziv',link='$link' WHERE id=$id";
    $rezultat=mysqli_query($conn,$upit);
    if($rezultat){
        header('Location: admin.php?page=navigacija');
    }
}
?>
<?php foreach($result as $r):?>
    <div class="col-lg-12  col-lg-offset-5 centred">
        <form class="form-horizontal" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
            <fieldset>
                <div id="legend">
                    <legend class="">Izmeni</legend>
                </div>
                <input type="hidden" name="id" value="<?php echo $r['id']?>">
                <div class="control-group">
                    <!-- E-mail -->
                    <label class="control-label" >Naziv</label>
                    <div class="controls">
                        <input type="text" value="<?php echo $r['naziv'];?>" name="naziv" placeholder="" class="input-xlarge">
                    </div>
                </div>

                <div class="control-group">
                    <!-- Password -->
                    <label class="control-label"  for="telephone">Link</label>
                    <div class="controls">
                        <input type="text" value="<?php echo $r['link'];?>" name="link" placeholder="" class="input-xlarge">
                    </div>
                </div>

                <div class="control-group">
                    <!-- Button -->
                    <div class="controls">
                        </br>
                        <button type="submit" class="btn btn-success" name="izmeni">Izmeni</button>
                    </div>
                </div>
            </fieldset>
        </form>
    </div>
<?php endforeach;?>