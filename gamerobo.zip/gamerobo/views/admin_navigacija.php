<?php
include('../konekcija.php');
$upit="SELECT * from navigacija";
$result=mysqli_query($conn,$upit);
mysqli_fetch_array($result);
?>
<link rel="stylesheet" type="text/css" href="../vendor/bootstrap/css/bootstrap.min.css">
<table class="table table-bordered">
  <thead>
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Naziv</th>
      <th scope="col">Link</th>
      <th scope="col">Izmena/Brisanje</th>
    </tr>
  </thead>
  <tbody>
<?php foreach($result as $r):?>
    <tr>
      <th scope="row"><?php echo $r['id']?></th>
      <td><?php echo $r['naziv']?></td>
      <td><?php echo $r['link']?></td>
      <td><a href="izmeninavigaciju.php?id=<?php echo $r['id'];?>"><button type="button" class="btn btn-primary">Izmeni</button></a>&nbsp<a href="delete.php?id=<?php echo $r['id'];?>&tip=navigacija"><button type="button" class="btn btn-danger">Obrisi</button></a></td></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
