<?php
include('../konekcija.php');
 $id=$_GET['id'];
 $tip=$_REQUEST['tip'];
 $upit="DELETE FROM $tip WHERE id=$id";
 $result=mysqli_query($conn,$upit);
 header('Location:admin.php');
 ?>
