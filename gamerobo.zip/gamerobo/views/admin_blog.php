<?php
include('../konekcija.php');
$upit="SELECT * from blog";
$result=mysqli_query($conn,$upit);
mysqli_fetch_array($result);
?>
<link rel="stylesheet" type="text/css" href="../vendor/bootstrap/css/bootstrap.min.css">
<table class="table table-bordered">
  <thead>
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Naslov</th>
      <th scope="col">Datum</th>
      <th scope="col">Alt</th>
    </tr>
  </thead>
  <tbody>
<?php foreach($result as $r):?>
    <tr>
      <th scope="row"><?php echo $r['id']?></th>
        <td><?php echo $r['putanja']?></td>
        <td><?php echo $r['tekst']?></td>
        <td><?php echo $r['detaljnije']?></td>
      <td><?php echo $r['naslov']?></td>
      <td><?php echo $r['datum']?></td>
        <td><?php echo $r['alt']?>&nbsp&nbsp<a href="izmeniblog.php?id=<?php echo $r['id'];?>"><button type="button" class="btn btn-primary">Izmeni</button></a>&nbsp<a href="delete.php?id=<?php echo $r['id'];?>&tip=blog"><button type="button" class="btn btn-danger">Obrisi</button></a></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
