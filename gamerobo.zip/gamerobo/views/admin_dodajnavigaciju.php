<?php
if(isset($_REQUEST['dodajnavigaciju'])){
    $naziv=$_REQUEST['naziv'];
    $link="index.php?page=".$naziv;
    $naziv=$_REQUEST['naziv'];
        $upit="INSERT INTO navigacija(naziv,link) VALUES('$naziv','$link')";
        $result=mysqli_query($conn,$upit);
}
?>
<form class="form-horizontal" action="admin.php?page=dodajnavigaciju" method="POST" enctype="multipart/form-data">
    <fieldset>
        <div id="legend">
            <legend class="">Dodaj navigaciju</legend>
        </div>
        <div class="control-group">
            <!-- Username -->
            <label class="control-label">Naziv</label>
            <div class="controls">
                <input type="text" name="naziv" placeholder="" class="input-xlarge">

            </div>
        </div
        <div class="control-group">
            <!-- Button -->
            <div class="controls">
                </br>
                <button type="submit" class="btn btn-success" name="dodajnavigaciju">Dodaj</button>
            </div>
        </div>
    </fieldset>
</form>
