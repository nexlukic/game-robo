<?php
include('../konekcija.php');
$upit="SELECT * from igrice";
$result=mysqli_query($conn,$upit);
mysqli_fetch_array($result);
?>
<link rel="stylesheet" type="text/css" href="../vendor/bootstrap/css/bootstrap.min.css">
<table class="table table-bordered">
  <thead>
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Ime</th>
      <th scope="col">putanja slike</th>
      <th scope="col">broj preuzimanja</th>
      <th scope="col">zanr</th>
      <th scope="col">anketa</th>
    </tr>
  </thead>
  <tbody>
<?php foreach($result as $r):?>
    <tr>
      <th scope="row"><?php echo $r['id']?></th>
      <td><?php echo $r['naziv']?></td>
      <td><?php echo $r['putanja']?></td>
      <td><?php echo $r['broj']?></td>
      <td><?php echo $r['id_zandra']?></td>
      <td><?php echo $r['anketa']?>&nbsp&nbsp<a href="izmeniigricu.php?id=<?php echo $r['id'];?>"><button type="button" class="btn btn-primary">Izmeni</button></a>&nbsp<a href="delete.php?id=<?php echo $r['id'];?>&tip=igrice"><button type="button" class="btn btn-danger">Obrisi</button></a></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
