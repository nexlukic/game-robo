<?php
$upit="SELECT * from slajder";
$result=mysqli_query($conn,$upit);
mysqli_fetch_array($result);
 ?>
<!-- Slider -->
<div class="slider">
  <ul class="rslides" id="slider">
    <?php foreach($result as $r) :?>
    <li class="<?php echo $r['klasa']?>">
      <img src="<?php echo $r['putanja']?>" alt="<?php echo $r['alt']?>">
      <div class="heading">
        <h1>GAME ROBO</h1>
        <h2>FREE FULL GAMES</h2>
        <h3>A UNIQUE PLACE TO DOWNLOAD</h3>
      </div>
    </li>
  <?php endforeach; ?>
  </ul>
</div>
<!-- //Slider -->
</div>
<!-- //Header -->
