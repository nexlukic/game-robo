<?php
if(isset($_REQUEST['dodajblog'])){
    $naslov=$_REQUEST['naslov'];
    $putanja="images/".basename( $_FILES['file']['name']);
    $tekst=$_REQUEST['tekst'];
    $detaljnije=$_REQUEST['detaljnije'];
    $alt=$_REQUEST['alt'];
    $putanja="images/".basename( $_FILES['file']['name']);
    $target = "../images/";
    $target = $target . basename( $_FILES['file']['name']);
    $file1=($_FILES['file']['name']);
    if(move_uploaded_file($_FILES['file']['tmp_name'], $target))  {
//Tells you if its all ok
        $upit="INSERT INTO blog(naslov,putanja,tekst,datum,alt,detaljnije) VALUES('$naslov','$putanja','$tekst',NOW(),'$alt','$detaljnije')";
        $result=mysqli_query($conn,$upit);
    }
    else {
//Gives and error if its not  echo "Sorry, there was a problem uploading your file.";      }
    }
}
?>
<form class="form-horizontal" action="admin.php?page=dodajblog" method="POST" enctype="multipart/form-data">
    <fieldset>
        <div id="legend">
            <legend class="">Dodavanje igrice</legend>
        </div>
        <div class="control-group">
            <!-- Username -->
            <label class="control-label"  for="username">Naslov bloga</label>
            <div class="controls">
                <input type="text"  name="naslov" placeholder="" class="input-xlarge">

            </div>
        </div>

        <div class="control-group">
            <!-- E-mail -->
            <label class="control-label" >Dodaj sliku</label>
            <div class="controls">
                <input type="file" name="file">
            </div>
        </div>
        <div class="control-group">
            <!-- Username -->
            <label class="control-label"  for="username">Tekst</label>
            <div class="controls">
                <textarea type="text" name="tekst" placeholder="" class="input-xlarge"></textarea>

            </div>
        </div>
        <div class="control-group">
            <!-- Username -->
            <label class="control-label"  for="username">Detaljnije</label>
            <div class="controls">
                <textarea type="text" name="detaljnije" placeholder="" class="input-xlarge"></textarea>

            </div>
        </div>
        <div class="control-group">
            <!-- Username -->
            <label class="control-label"  for="username">Alt</label>
            <div class="controls">
                <input type="text" id="username" name="alt" placeholder="" class="input-xlarge">

            </div>
        </div

        <div class="control-group">
            <!-- Button -->
            <div class="controls">
                </br>
                <button type="submit" class="btn btn-success" name="dodajblog">Dodaj</button>
            </div>
        </div>
    </fieldset>
</form>
