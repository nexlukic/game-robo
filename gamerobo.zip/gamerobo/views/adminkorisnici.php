<?php
include('../konekcija.php');
$upit="SELECT * from korisnici";
$result=mysqli_query($conn,$upit);
mysqli_fetch_array($result);

?>
<link rel="stylesheet" type="text/css" href="../vendor/bootstrap/css/bootstrap.min.css">
<table class="table table-bordered">
  <thead>
    <tr>
      <th scope="col">id</th>
      <th scope="col">username</th>
      <th scope="col">password</th>
      <th scope="col">email</th>
      <th scope="col">telefon</th>
      <th scope="col">datum registracije</th>
    </tr>
  </thead>
  <tbody>
<?php foreach($result as $r):?>
    <tr>
      <th scope="row"><?php echo $r['id']?></th>
      <td><?php echo $r['username']?></td>
      <td><?php echo $r['password']?></td>
      <td><?php echo $r['email']?></td>
      <td><?php echo $r['telefon']?></td>
      <td><?php echo $r['datum']?>&nbsp&nbsp<a href="izmenikorisnika.php?id=<?php echo $r['id'];?>"><button type="button" class="btn btn-primary">Izmeni</button></a>&nbsp<a href="delete.php?id=<?php echo $r['id'];?>&tip=korisnici"><button type="button" class="btn btn-danger">Obrisi</button></a></td>
    </tr>
  <?php endforeach; ?>
  </tbody>


</table>
<div class="row">
  <div class="col-md-12 text-center">
    <a href="admin.php?page=korisnici&dodajkorisnika"><button type="button" name="dodajkorisnika" class="btn btn-primary">Dodaj korisnika</button>
  </div>
</div>
<div class="row">
  <div class="col-md-12 text-center">
  <?php
    if($page == 'korisnici$dodajkorisnika'){
      include('admin_dodajkorisnika.php');
    }

  ?>
</div>
</div>
