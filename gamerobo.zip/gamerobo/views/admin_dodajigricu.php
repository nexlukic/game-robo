<?php
if(isset($_REQUEST['dodajigricu'])){
$naziv=$_REQUEST['imeIgrice'];
$putanja="images/".basename( $_FILES['file']['name']);
$zanr=$_REQUEST['zanr'];
$target = "../images/";
$target = $target . basename( $_FILES['file']['name']);
$file1=($_FILES['file']['name']);
if(move_uploaded_file($_FILES['file']['tmp_name'], $target))  {
//Tells you if its all ok
$upit="INSERT INTO igrice(naziv,putanja,broj,id_zandra,anketa) VALUES('$naziv','$putanja',0,'$zanr',5)";
$result=mysqli_query($conn,$upit);
}
else {
//Gives and error if its not  echo "Sorry, there was a problem uploading your file.";      }
}
}
?>
<?php
$upit="SELECT * from zanr";
$rezultat=mysqli_query($conn,$upit);

?>
<form class="form-horizontal" action="admin.php?page=dodajigricu" method="POST" enctype="multipart/form-data">
  <fieldset>
    <div id="legend">
      <legend class="">Dodavanje igrice</legend>
    </div>
		  <div class="control-group">
    <select name="zanr" class="selectpicker">
      <?php foreach($rezultat as $r):?>
  <option value="<?php echo $r['id'];?>"><?php echo$r['ime_zanra'];?></option>
<?php endforeach;?>
</select>
</div>
    <div class="control-group">
      <!-- Username -->
      <label class="control-label"  for="username">Ime igrice</label>
      <div class="controls">
        <input type="text" id="username" name="imeIgrice" placeholder="" class="input-xlarge">

      </div>
    </div>

    <div class="control-group">
      <!-- E-mail -->
      <label class="control-label" >Dodaj sliku</label>
      <div class="controls">
        <input type="file" name="file">
      </div>
    </div>



    <div class="control-group">
      <!-- Button -->
      <div class="controls">
      </br>
        <button type="submit" class="btn btn-success" name="dodajigricu">Dodaj</button>
      </div>
    </div>
  </fieldset>
</form>

