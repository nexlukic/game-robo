<!-- Contact -->
<div class="agilecontactw3ls" id="agilecontactw3ls">
  <div class="container">
    <h3>Write to Us</h3>
    <form action="#" method="post">
      <div class="col-md-6 agilecontactw3ls-grid agilecontactw3ls-grid-1">
        <input type="text" Name="First Name" placeholder="FIRST NAME" required="">
        <input type="text" Name="Last Name" placeholder="LAST NAME" required="">
        <input type="email" Name="Email" placeholder="EMAIL" required="">
      </div>
      <div class="col-md-6 agilecontactw3ls-grid agilecontactw3ls-grid-2">
        <textarea name="Message" placeholder="MESSAGE" required=""></textarea>
        <div class="send-button">
          <input type="submit" value="SEND">
        </div>
      </div>
    </form>
  </div>
</div>
<!-- //Contact -->
