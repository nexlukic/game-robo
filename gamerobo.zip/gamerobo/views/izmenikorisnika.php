<link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<!-- MetisMenu CSS -->
<link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

<!-- Custom CSS -->
<link href="../data/dist/css/sb-admin-2.css" rel="stylesheet">

<!-- Morris Charts CSS -->
<link href="../vendor/morrisjs/morris.css" rel="stylesheet">

<!-- Custom Fonts -->
<link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<?php
include('../konekcija.php');
 $id=$_REQUEST['id'];
 echo $id;
 $upit="SELECT * from korisnici where id=$id";
 $result=mysqli_query($conn,$upit);
 //mysqli_fetch_array($result);
 if(isset($_REQUEST['izmeni'])){
 	$username=$_REQUEST['username'];
 	$password=$_REQUEST['password'];
 	$email=$_REQUEST['email'];
 	$telefon=$_REQUEST['telefon'];
 	$uloga=$_REQUEST['uloga'];
  $id=$_REQUEST['id'];
 	$upit="UPDATE korisnici SET username='$username',password='$password',email='$email',telefon='$telefon',id_uloga=$uloga WHERE id=$id";
 	$rezultat=mysqli_query($conn,$upit);
  if($rezultat){
  header('Location: admin.php?page=korisnici');
  }
 }
  ?>
<?php foreach($result as $r):?>
<div class="col-lg-12  col-lg-offset-5 centred">
  <form class="form-horizontal" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
    <fieldset>
      <div id="legend">
        <legend class="">Izmeni</legend>
      </div>
      <input type="hidden" name="id" value="<?php echo $r['id']?>">
  		  <div class="control-group">
      <select name="uloga" class="selectpicker">
    <?php if($r[id_uloga]==1):?>
    <option value="1">Admin</option>
    <option value="2">Korisnik</option>
  <?php else:?>
    <option value="2">Korisnik</option>
    <option value="1">Admin</option>
  <?php endif;?>
  </select>
  </div>
      <div class="control-group">
        <!-- Username -->
        <label class="control-label"  for="username">Username</label>
        <div class="controls">
          <input type="text" id="username" value="<?php echo $r['username'];?>" name="username" placeholder="" class="input-xlarge">

        </div>
      </div>

      <div class="control-group">
        <!-- E-mail -->
        <label class="control-label" >Password</label>
        <div class="controls">
          <input type="password" value="<?php echo $r['password'];?>" name="password" placeholder="" class="input-xlarge">
        </div>
      </div>

      <div class="control-group">
        <!-- Password-->
        <label class="control-label" >Email</label>
        <div class="controls">
          <input type="text" value="<?php echo $r['email'];?>" name="email" placeholder="" class="input-xlarge">
        </div>
      </div>

      <div class="control-group">
        <!-- Password -->
        <label class="control-label"  for="telephone">Telefon</label>
        <div class="controls">
          <input type="text" value="<?php echo $r['telefon'];?>" name="telefon" placeholder="" class="input-xlarge">
        </div>
      </div>

      <div class="control-group">
        <!-- Button -->
        <div class="controls">
        </br>
          <button type="submit" class="btn btn-success" name="izmeni">Izmeni</button>
        </div>
      </div>
    </fieldset>
  </form>
</div>
<?php endforeach;?>
