<?php
$upit="SELECT * from slajder2";
$resultslajder=mysqli_query($conn,$upit);
mysqli_fetch_array($resultslajder);
?>
<!-- Partners -->
<div class="aitspartnersw3l">
  <div id="owl-demo4" class="owl-carousel text-center">
    <?php foreach($resultslajder as $r) :?>
    <div class="item">
      <img src="<?php echo $r['putanja']?>" alt="<?php echo $r['alt']?>">
    </div>
  <?php endforeach; ?>
<!-- //Partners -->
</div>
</div>
