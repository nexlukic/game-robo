<?php
include('../konekcija.php');
$upit="SELECT * from slajder";
$result=mysqli_query($conn,$upit);
mysqli_fetch_array($result);
?>
<link rel="stylesheet" type="text/css" href="../vendor/bootstrap/css/bootstrap.min.css">
<table class="table table-bordered">
  <thead>
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Putanja</th>
      <th scope="col">Klasa</th>
      <th scope="col">Alt</th>
    </tr>
  </thead>
  <tbody>
<?php foreach($result as $r):?>
    <tr>
      <th scope="row"><?php echo $r['id']?></th>
      <td><?php echo $r['putanja']?></td>
      <td><?php echo $r['klasa']?></td>
      <td><?php echo $r['alt']?>&nbsp&nbsp<a href="izmenislajder.php?id=<?php echo $r['id'];?>"><button type="button" class="btn btn-primary">Izmeni</button></a>&nbsp<a href="delete.php?id=<?php echo $r['id'];?>&tip=slajder"><button type="button" class="btn btn-danger">Obrisi</button></a></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
