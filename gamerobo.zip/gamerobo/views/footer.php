<!-- Footer -->
<div class="agilefooterwthree" id="agilefooterwthree">
  <div class="container">



    <div class="agilefooterwthreebottom">

      <div class="col-md-6 agilefooterwthreebottom-grid agilefooterwthreebottom-grid2">
        <div class="agilesocialwthree">
          <ul class="social-icons">
            <li><a href="https://www.facebook.com/nemanja.lukic.5661" class="facebook w3ls" title="Go to Our Facebook Page"><i class="fa w3ls fa-facebook-square" aria-hidden="true"></i></a></li>
            <li><a href="https://www.instagram.com/nexlukic/" class="instagram wthree" title="Go to Our Instagram Account"><i class="fa wthree fa-instagram" aria-hidden="true"></i></a></li>
          </ul>
        </div>
      </div>
    </div>

  </div>

  <a href="#agileitshome" class="agileto-top scroll" title="To Top"><img src="images/to-top.png" alt="Game Robo"></a>

</div>
<!-- //Footer -->



<!-- C
