<?php
if(isset($_REQUEST['dodajslajder2'])){
    $putanja="images/".basename( $_FILES['file']['name']);
    $alt=$_REQUEST['alt'];
    $target = "../images/";
    $target = $target . basename( $_FILES['file']['name']);
    $file1=($_FILES['file']['name']);
    if(move_uploaded_file($_FILES['file']['tmp_name'], $target))  {
//Tells you if its all ok
        $upit="INSERT INTO slajder2(putanja,alt) VALUES('$putanja','$alt')";
        $result=mysqli_query($conn,$upit);
    }
    else {
//Gives and error if its not  echo "Sorry, there was a problem uploading your file.";      }
    }
}
?>
<form class="form-horizontal" action="admin.php?page=dodajslajder" method="POST" enctype="multipart/form-data">
    <fieldset>
        <div id="legend">
            <legend class="">Dodavanje Slajdera</legend>
        </div>
        <div class="control-group">
            <!-- E-mail -->
            <label class="control-label" >Dodaj sliku</label>
            <div class="controls">
                <input type="file" name="file">
            </div>
        </div>
        <div class="control-group">
            <!-- Username -->
            <label class="control-label"  for="username">Alt</label>
            <div class="controls">
                <input type="text" id="username" name="alt" placeholder="" class="input-xlarge">

            </div>
        </div



        <div class="control-group">
            <!-- Button -->
            <div class="controls">
                </br>
                <button type="submit" class="btn btn-success" name="dodajslajder">Dodaj</button>
            </div>
        </div>
    </fieldset>
</form>
