<?php
$upit="SELECT * from blog";
$result=mysqli_query($conn,$upit);
mysqli_fetch_array($result);
?>
	<!-- Blogs -->
	<div class="wthreeblogsaits" id="wthreeblogsaits">
		<div class="wthreeblogsaits-grids">

			<h3>Latest Blogs & News</h3>
			<?php foreach($result as $r) :?>
			<div class="col-md-3 wthreeblogsaits-grid wthreeblogsaits-grid-1">
				<a href="#" data-toggle="modal" data-target="<?php echo $r['target']?>"><img src="<?php echo $r['putanja']?>" alt="<?php echo $r['alt']?>"></a>
				<span class="w3date"><?php echo $r['datum']?></span>
				<h4><a href="#" data-toggle="modal" data-target="<?php echo $r['target']?>"><?php echo $r['naslov']?></a></h4>
				<p><?php echo $r['tekst']?></p>
				<button class="btn btn-primary" data-toggle="modal" data-target="<?php echo $r['target']?>">READ MORE<i class="fa fa-arrow-right" aria-hidden="true"></i></button>
			</div>
		<?php endforeach;?>
			<div class="clearfix"></div>
		</div>

		<!-- Tooltip-Content -->
		<div class="tooltip-content">
<?php foreach($result as $r):?>
			<div class="modal fade details-modal" id="myModal<?php echo $r['id']?>" tabindex="-1" role="dialog" aria-hidden="true">
				<div class="modal-dialog modal-lg">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
							<h4 class="modal-title"><?php echo $r['naslov']?></h4>
						</div>
						<div class="modal-body">
							<img src="<?php echo $r['putanja']?>" alt="Game Robo">
							<p><?php echo $r['detaljnije']?></p>
						</div>
					</div>
				</div>
			</div>
<?php endforeach; ?>
		</div>
		<!-- //Tooltip-Content -->

	</div>

	<!-- //Blogs -->
