<?php
include('../konekcija.php');
if(isset($_REQUEST['id']))
{
    $id = $_REQUEST['id'];
    $upit = "UPDATE igrice SET broj = broj + 1 WHERE id = $id;";
    $updated = mysqli_query($conn,$upit);
    if($updated) {
        $upit = "SELECT * FROM igrice;";
        $result = mysqli_query($conn, $upit);
        if (mysqli_num_rows($result)) {
            $upit_ukupno = "SELECT broj FROM igrice where id = $id;";
            $result_ukupno = mysqli_query($conn, $upit_ukupno);
            $rezultat=mysqli_fetch_array( $result_ukupno);

             echo $rezultat['broj'].' '.'Downloads';
        }

    }}