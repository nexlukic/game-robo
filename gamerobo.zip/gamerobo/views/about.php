<!-- About -->
<?php
$upit="SELECT * from about";
$result=mysqli_query($conn,$upit);
mysqli_fetch_array($result);
?>
<div class="w3lsaboutaits" id="w3lsaboutaits">
  <div class="container">
    <?php foreach($result as $r):?>
    <div class="w3lsaboutaits-grids">
      <div class="col-md-6 w3lsaboutaits-grid w3lsaboutaits-grid-1">
        <h3><?php echo $r['naslov']?></h3>
        <p><?php echo $r['tekst']?></p>
      </div>
      <div class="col-md-6 w3lsaboutaits-grid w3lsaboutaits-grid-2">
        <img src="<?php echo $r['putanja']?>" alt="Game Robo">
      </div>
      <div class="clearfix"></div>
    </div>
  <?php endforeach; ?>
  </div>
</div>
<?php
$upit = "SELECT * from anketa";
$rezultatanketa = mysqli_query($conn,$upit);
$status=1;
if(isset($_SESSION['status_anketa'])){
    $status=$_SESSION['status_anketa'];
}
?>
<?php if((mysqli_num_rows($rezultatanketa))&&$status==0): ?>
    <div class="row" style="background-color:black";>
        <div class="container">
            <div class="col-md-3 col-md-offset-4">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Oceni moj sajt!
                    </div>
                    <div class="panel-body" style="background-color:white;">
                        <table class="table table table-condensed">
                            <?php while($a = mysqli_fetch_array($rezultatanketa)): ?>
                                <tr>
                                    <td><?php echo $a['opcija']; ?></td><td><input type="radio" name="vote" value="<?php echo $a['id']; ?>"></td>
                                </tr>
                            <?php endwhile; ?>
                        </table>
                        <?php if(isset($_SESSION['id'])){
                           $id_korisnika=$_SESSION['id'];
                           echo "<input type='hidden' value='$id_korisnika' name='id_korisnika'";
                        }

                            ?>
                    </div>
                    <div class="panel-footer">
                        <button onClick="vote()" type="button" id="vote" class="btn btn-primary">Vote!</button>
                        <div id="anketaFeedback" class="text-center">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>


