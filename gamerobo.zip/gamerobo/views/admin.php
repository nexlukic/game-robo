
<?php
session_start();
if(isset($_SESSION['uloga'])){
    $uloga=$_SESSION['uloga'];
    if($uloga=='admin'){
        echo "moze";
    }
    else{
        $Message = "IDES POC MAC BATO";
        header("Location:../index.php?message={$Message}");
    }
}
else{
    $Message = "IDES POC MAC BATO";
    header("Location:../index.php?message={$Message}");
}
?>
<?php
include('../konekcija.php');
if(isset($_REQUEST['register'])){
	$username=$_REQUEST['username'];
	$password=$_REQUEST['password'];
	$email=$_REQUEST['email'];
	$telefon=$_REQUEST['telefon'];
	$uloga=$_REQUEST['uloga'];

	$upit="INSERT into korisnici(username,password,email,telefon,id_uloga,datum) VALUES('$username','$password','$email','$telefon','$uloga',NOW())";
	$result=mysqli_query($conn,$upit);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SB Admin 2 - Bootstrap Admin Theme</title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../data/dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="../vendor/morrisjs/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">SB Admin v2.0</a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                <li>
                    <a href="../logout.php">
                        Logout
                    </a>

                    <!-- /.dropdown-tasks -->
                </li>

                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar-search">
                            <div class="input-group custom-search-form">
                                <input type="text" class="form-control" placeholder="Search...">
                                <span class="input-group-btn">
                                <button class="btn btn-default" type="button">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                            </div>
                            <!-- /input-group -->
                        </li>
                        <li class="dropdown"><a class="dropdown-toggle"
        data-toggle="dropdown">Korisnici <b class="caret"></b></a>
        <ul class="dropdown-menu">
          <li><a href="admin.php?page=korisnici">Prikazi</a></li>
          <li><a href="admin.php?page=dodajkorisnika">Dodaj</a></li>
        </ul></li>


                                <li class="dropdown"><a href="#" class="dropdown-toggle"
                data-toggle="dropdown">Igrice<b class="caret"></b></a>
                <ul class="dropdown-menu">
                  <li><a href="admin.php?page=igrice">Prikazi</a></li>
                  <li><a href="admin.php?page=dodajigricu">Dodaj</a></li>
                </ul></li>
                <li class="dropdown"><a href="#" class="dropdown-toggle"
               data-toggle="dropdown">Blogovi<b class="caret"></b></a>
                     <ul class="dropdown-menu">
                    <li><a href="admin.php?page=blog">Prikazi</a></li>
                       <li><a href="admin.php?page=dodajblog">Dodaj</a></li>
                         </ul></li>
                         <li class="dropdown"><a href="#" class="dropdown-toggle"
         data-toggle="dropdown">Slajder<b class="caret"></b></a>
         <ul class="dropdown-menu">
           <li><a href="admin.php?page=slajder">Prikazi</a></li>
           <li><a href="admin.php?page=dodajslajder">Dodaj</a></li>
         </ul></li>
         <li class="dropdown"><a href="#" class="dropdown-toggle"
data-toggle="dropdown">Slajder2<b class="caret"></b></a>
<ul class="dropdown-menu">
<li><a href="admin.php?page=slajder2">Prikazi</a></li>
<li><a href="admin.php?page=dodajslajder2">Dodaj</a></li>
</ul></li>

<li class="dropdown"><a href="#" class="dropdown-toggle"
data-toggle="dropdown">Navigacija<b class="caret"></b></a>
<ul class="dropdown-menu">
<li><a href="admin.php?page=navigacija">Prikazi</a></li>
<li><a href="admin.php?page=dodajnavigaciju">Dodaj</a></li>
</ul></li>
                        <li class="dropdown"><a href="#" class="dropdown-toggle"
                                                data-toggle="dropdown">Anketa<b class="caret"></b></a>
                            <ul class="dropdown-menu">
                                <li><a href="admin.php?page=anketa">Prikazi</a></li>
                                <li><a href="admin.php?page=dodajanketu">Dodaj</a></li>
                            </ul></li>





                                    </ul>
                                    <!-- /.nav-third-level -->
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>



            <!-- /.row -->

            <!-- /.row -->

                <div class="col-lg-4">


                </div>
                <!-- /.col-lg-8 -->
                <div class="col-lg-8">
                <?php
                  if (isset($_GET['page'])){
                    $page = $_GET['page'];
                    if($page == 'korisnici'){
                      include('adminkorisnici.php');
                    }
                    if($page == 'igrice'){
                      include('admini_igrice.php');
                    }
                    if($page == 'blog'){
                      include('admin_blog.php');
                    }
                    if($page == 'slajder'){
                      include('admin_slajder.php');
                    }
                    if($page == 'slajder2'){
                      include('admin_slajder2.php');
                    }
                    if($page == 'navigacija'){
                      include('admin_navigacija.php');
                    }
                    if($page == 'dodajkorisnika'){
                      include('admin_dodajkorisnika.php');
                    }
										if($page == 'dodajigricu'){
                      include('admin_dodajigricu.php');
                    }
                      if($page == 'dodajblog'){
                          include('admin_dodajblog.php');
                      }
                      if($page == 'dodajslajder'){
                          include('admin_dodajslajder.php');
                      }
                      if($page == 'dodajslajder2'){
                          include('admin_dodajslajder2.php');
                      }
                      if($page == 'dodajnavigaciju'){
                          include('admin_dodajnavigaciju.php');
                      }
                      if($page == 'anketa'){
                          include('admin_anketa.php');
                      }
                      if($page == 'dodajanketu'){
                          include('anketa_dodaj.php');
                      }
                  }
                    ?>
                </div>
                <!-- /.col-lg-4 -->
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
</body>
    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="../vendor/raphael/raphael.min.js"></script>
    <script src="../vendor/morrisjs/morris.min.js"></script>
    <script src="../data/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>
