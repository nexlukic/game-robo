function vote()
{
    id = $('input[name=vote]:checked').val();
    id_korisnika = $('input[name=id_korisnika]').val();
    if(id)
    {
        $.ajax({
            url: 'views/vote.php',
            type: 'POST',
            data: {
                id_glasa: id,
                id_korisnika:id_korisnika
            },
            success: function(data)
            {
                $("#vote").hide();
                $("#anketaFeedback").html("<i class='fa fa-spin fa-cog'><i>");
                setInterval(function () {
                    $("#anketaFeedback").html(data);
                }, 400);
            },
            error: function(xhr)
            {
                $("#anketaFeedback").html(xhr.responseText);
            }
        });
    }
    else {
        $("#anketaFeedback").html("<p class='text-danger'>You must choose an option. </p>");
    }
}

function registracija(){
    var greske=[];
    var username=document.querySelector('#username').value;
    var password=document.querySelector('#password').value;
    var email=document.querySelector('#email').value;
    var telefon=document.querySelector('#telefon').value;
    var reemail=/^[a-zA-Z0-9.]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
    var retelefon=/^[0-9]{3}-[0-9]{4}-[0-9]{3,4}$/;
    var repassword=/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{5,}$/;
    var reusername=/^[A-Za-z]{1}[A-Za-z0-9]{5,31}$/;

    if(!reusername.test(username)){
        greske.push("<p class='text-danger'>username nije u dobrom formatu!</p>");
    }
    if(!repassword.test(password)){
        greske.push("<p class='text-danger'>password nije u dobrom formatu!'</p>");

    }
    if(!retelefon.test(telefon)){
        greske.push("<p class='text-danger'>telefon nije u dobrom formatu mora biti(000-0000-000)!</p>");

    }
    if(!reemail.test(email)){
        greske.push("<p class='text-danger'>email nije u dobrom formatu!</p>");
    }
    if(greske.length>0){
        for(i=0;i<greske.length;i++){
            document.querySelector("#greske").innerHTML+=greske[i];

        }
        return false;
    }
    if(greske.length==0){
        document.querySelector('#greske').innerHTML+=("<p class='text-success'>usnespo ste se registrovali!</p>");
        return true;


    }
}