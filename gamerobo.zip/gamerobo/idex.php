
<?php
include('konekcija.php');
?>
<?php
if(isset($_REQUEST['message'])){
    echo $_REQUEST['message'];
}
?>

<!DOCTYPE html>
<html lang="zxx">



<!-- Head -->
<head>

<title>Game Robo a Gaming Category Bootstrap Responsive Website Template | Home :: W3layouts</title>

<!-- Meta-Tags -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="keywords" content="Game Robo a Responsive Web Template, Bootstrap Web Templates, Flat Web Templates, Android Compatible Web Template, Smartphone Compatible Web Template, Free Webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola Web Design">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //Meta-Tags -->

<!-- Custom-Stylesheet-Links -->
<!-- Bootstrap-CSS -->	  <link rel="stylesheet" href="css/bootstrap.min.css"  type="text/css" media="all">
<!-- Index-Page-CSS -->	  <link rel="stylesheet" href="css/style.css"		   type="text/css" media="all">
<!-- Owl-Carousel-CSS --> <link rel="stylesheet" href="css/owl.carousel.css"   type="text/css" media="all">
<!-- Chocolat-CSS -->	  <link rel="stylesheet" href="css/chocolat.css"	   type="text/css" media="all">
<!-- Animate-CSS -->	  <link rel="stylesheet" href="css/animate-custom.css" type="text/css" media="all">
<!-- //Custom-Stylesheet-Links -->

<!-- Fonts -->
<link rel="stylesheet" href="//fonts.googleapis.com/css?family=Montserrat:400,700"	   type="text/css" media="all">
<link rel="stylesheet" href="//fonts.googleapis.com/css?family=Roboto:400,100,300,500" type="text/css" media="all">
<link rel="stylesheet" href="//fonts.googleapis.com/css?family=Press+Start+2P"		   type="text/css" media="all">
<!-- //Fonts -->

<!-- Font-Awesome-File-Links -->
<!-- CSS --> <link rel="stylesheet" href="css/font-awesome.min.css" 	 type="text/css" media="all">
<!-- TTF --> <link rel="stylesheet" href="fonts/fontawesome-webfont.ttf" type="text/css" media="all">
<!-- //Font-Awesome-File-Links -->


</head>
<div id="ipaddress"></div>
<?php
include('views/navigacija.php');
include('views/slajder.php');
if(isset($_GET['page'])) {
    $page = $_GET['page'];
    switch ($page) {

        case "about"    :
            include_once('views/about.php');
            break;
        case "igrice"  :
            include_once('views/igrice.php');
            break;
        case "kontakt" :
            include_once('views/kontakt.php');
            break;
        case  "blog"   :
            include_once('views/blog.php');
            break;

    }
}
else{
    include('views/about.php');
}
include('views/slajder2.php');
include('views/footer.php');
 ?>
 ustom-JavaScript-File-Links -->

<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/vote.js"></script>
<script type="text/javascript" src="js/download.js"></script>

   <!-- Resopnsive-Slider-JavaScript -->
     <script src="js/responsiveslides.min.js"></script>
     <script>
       $(function () {
         $("#slider").responsiveSlides({
           auto: true,
           nav: true,
           speed: 2000,
           namespace: "callbacks",
           pager: true,
         });
       });
     </script>
   <!-- //Resopnsive-Slider-JavaScript -->

   <!-- Tab-JavaScript -->
     <script src="js/cbpFWTabs.js"></script>
     <script>
       (function() {
         [].slice.call( document.querySelectorAll( '.tabs' ) ).forEach( function( el ) {
           new CBPFWTabs( el );
         });
       })();
     </script>
   <!-- //Tab-JavaScript -->

   <!-- Owl-Carousel-JavaScript -->
     <script src="js/owl.carousel.js"></script>
     <script>
       $(document).ready(function() {
         $("#owl-demo1, #owl-demo2, #owl-demo3, #owl-demo4").owlCarousel({
           autoPlay: 3000,
           items : 5,
           itemsDesktop : [1024,4],
           itemsDesktopSmall : [414,3]
         });
       });
     </script>
   <!-- //Owl-Carousel-JavaScript -->

   <!-- Stats-Number-Scroller-Animation-JavaScript -->
     <script src="js/waypoints.min.js"></script>
     <script src="js/counterup.min.js"></script>
     <script>
       jQuery(document).ready(function( $ ) {
         $('.counter').counterUp({
           delay: 10,
           time: 1000
         });
       });
     </script>
   <!-- //Stats-Number-Scroller-Animation-JavaScript -->

   <!-- Popup-Box-JavaScript -->
     <script src="js/jquery.chocolat.js"></script>
     <script type="text/javascript">
       $(function() {
         $('.w3portfolioaits-item a').Chocolat();
       });
     </script>
   <!-- //Popup-Box-JavaScript -->

   <!-- Smooth-Scrolling-JavaScript -->
     <script type="text/javascript">
       jQuery(document).ready(function($) {
         $(".scroll").click(function(event){
           event.preventDefault();
           $('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
         });
       });
     </script>
   <!-- //Smooth-Scrolling-JavaScript -->

 <!-- //Custom-JavaScript-File-Links -->



 </body>
 <!-- //Body -->



 </html>
